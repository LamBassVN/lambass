from resources.lib.service import GrabFanartService

# run the service
GrabFanartService().run()
